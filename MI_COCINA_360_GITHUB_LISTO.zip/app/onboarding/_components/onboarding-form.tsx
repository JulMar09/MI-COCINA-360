'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ChefHat, Building2, Globe, Coins } from 'lucide-react'
import { toast } from 'sonner'

const BUSINESS_TYPES = [
  'Restaurante',
  'Catering',
  'Hotel',
  'Bar / Cafetería',
  'Obrador',
  'Dark Kitchen',
  'Comedor Colectivo',
  'Otro',
]

const CURRENCIES = [
  { value: 'EUR', label: '€ Euro (EUR)' },
  { value: 'USD', label: '$ Dólar (USD)' },
  { value: 'GBP', label: '£ Libra (GBP)' },
  { value: 'MXN', label: '$ Peso MX (MXN)' },
]

export function OnboardingForm() {
  const [name, setName] = useState('')
  const [businessType, setBusinessType] = useState('')
  const [country, setCountry] = useState('España')
  const [currency, setCurrency] = useState('EUR')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name || !businessType) {
      toast.error('Completa todos los campos obligatorios')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/kitchens', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, businessType, country, currency }),
      })
      if (!res.ok) {
        const data = await res.json()
        toast.error(data?.error || 'Error al crear la cocina')
        return
      }
      toast.success('¡Cocina creada exitosamente!')
      router.push('/dashboard')
      router.refresh()
    } catch {
      toast.error('Error de conexión')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary/30 to-background px-4">
      <div className="w-full max-w-lg">
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-xl bg-primary flex items-center justify-center mb-4">
            <ChefHat className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-display font-bold tracking-tight">¡Bienvenido a MI COCINA 360!</h1>
          <p className="text-muted-foreground text-sm mt-1 text-center">Configura tu primera cocina para empezar</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Configurar Cocina</CardTitle>
            <CardDescription>Introduce los datos de tu negocio</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="kitchenName">Nombre del Negocio *</Label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="kitchenName"
                    placeholder="Ej: Restaurante El Buen Sabor"
                    className="pl-10"
                    value={name}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Tipo de Negocio *</Label>
                <Select value={businessType} onValueChange={setBusinessType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona el tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {BUSINESS_TYPES.map((t: string) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="country">País</Label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="country"
                      placeholder="España"
                      className="pl-10"
                      value={country}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCountry(e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Moneda</Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger>
                      <Coins className="w-4 h-4 text-muted-foreground mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CURRENCIES.map((c: { value: string; label: string }) => (
                        <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" loading={loading}>
                Crear Cocina y Empezar
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
