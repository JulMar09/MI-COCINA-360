import { auth } from '@/auth'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/db'
import { OnboardingForm } from './_components/onboarding-form'

export default async function OnboardingPage() {
  const session = await auth()
  if (!session?.user) redirect('/login')
  const kitchen = await prisma.kitchen.findFirst({ where: { userId: session.user.id } })
  if (kitchen) redirect('/dashboard')
  return <OnboardingForm />
}
