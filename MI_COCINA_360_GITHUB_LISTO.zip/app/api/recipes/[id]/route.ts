export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { getFoodCostConfig, getFoodCostStatus } from '@/lib/food-cost'
import { requirePermission } from '@/lib/permissions'

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('recipes:read')
  if ('error' in access) return access.error
  const { id } = await params
  const kitchen = access.kitchen
  const recipe = await prisma.recipe.findFirst({
    where: { id, kitchenId: kitchen.id },
    include: {
      ingredients: {
        include: { ingredient: { select: { id: true, name: true, costPerUnit: true, unit: true } } },
      },
    },
  })
  if (!recipe) return NextResponse.json({ error: 'Receta no encontrada' }, { status: 404 })

  const config = getFoodCostConfig(kitchen)
  const items = recipe?.ingredients ?? []

  // Coste actual
  const totalCost = items.reduce(
    (sum: number, ri: any) => sum + (ri?.quantity ?? 0) * (ri?.ingredient?.costPerUnit ?? 0), 0
  )
  const yieldQty = Math.max(recipe?.yield ?? 1, 1)
  const costPerPortion = totalCost / yieldQty
  const sellingPrice = recipe?.sellingPrice ?? 0
  const foodCostPercent = sellingPrice > 0 ? (costPerPortion / sellingPrice) * 100 : 0
  // Margen bruto sobre materia prima = precio de venta - coste por ración
  const grossMargin = sellingPrice > 0 ? sellingPrice - costPerPortion : 0

  // Ingredientes sin precio registrado (costPerUnit <= 0)
  const incompleteIngredients = items
    .filter((ri: any) => (ri?.ingredient?.costPerUnit ?? 0) <= 0)
    .map((ri: any) => ri?.ingredient?.name ?? '')
  const hasIncompleteCost = incompleteIngredients.length > 0

  const status = getFoodCostStatus(foodCostPercent, config, hasIncompleteCost)

  // Principal contribuyente al coste (solo entre ingredientes con precio)
  let topContributor: { name: string; subtotal: number; pct: number } | null = null
  if (totalCost > 0) {
    let best: any = null
    for (const ri of items) {
      const subtotal = (ri?.quantity ?? 0) * (ri?.ingredient?.costPerUnit ?? 0)
      if (subtotal > 0 && (best === null || subtotal > best.subtotal)) {
        best = { name: ri?.ingredient?.name ?? '', subtotal }
      }
    }
    if (best) topContributor = { name: best.name, subtotal: best.subtotal, pct: (best.subtotal / totalCost) * 100 }
  }

  // Evolución del coste usando el historial de precios existente.
  // Para cada ingrediente, se busca su precio anterior (2º registro más reciente).
  const ingredientIds = items.map((ri: any) => ri?.ingredient?.id).filter(Boolean)
  let costEvolution: { previousCost: number; currentCost: number; variationPct: number } | null = null
  if (ingredientIds.length > 0) {
    const history = await prisma.ingredientPriceHistory.findMany({
      where: { ingredientId: { in: ingredientIds } },
      orderBy: { date: 'desc' },
    })
    const prevPriceByIngredient: Record<string, number> = {}
    const countByIngredient: Record<string, number> = {}
    for (const h of history) {
      const iid = (h as any).ingredientId
      countByIngredient[iid] = (countByIngredient[iid] ?? 0) + 1
      // El 2º registro más reciente es el precio anterior
      if (countByIngredient[iid] === 2) prevPriceByIngredient[iid] = (h as any).price
    }
    const hasAnyPrevious = Object.keys(prevPriceByIngredient).length > 0
    if (hasAnyPrevious) {
      const previousTotal = items.reduce((sum: number, ri: any) => {
        const iid = ri?.ingredient?.id
        const prev = prevPriceByIngredient[iid]
        const price = typeof prev === 'number' ? prev : (ri?.ingredient?.costPerUnit ?? 0)
        return sum + (ri?.quantity ?? 0) * price
      }, 0)
      if (previousTotal > 0 && Math.abs(previousTotal - totalCost) > 0.0001) {
        costEvolution = {
          previousCost: previousTotal,
          currentCost: totalCost,
          variationPct: ((totalCost - previousTotal) / previousTotal) * 100,
        }
      }
    }
  }

  return NextResponse.json({
    ...recipe,
    analysis: {
      totalCost,
      costPerPortion,
      sellingPrice,
      foodCostPercent,
      grossMargin,
      status,
      config,
      hasIncompleteCost,
      incompleteIngredients,
      topContributor,
      costEvolution,
    },
  })
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('recipes:write')
  if ('error' in access) return access.error
  const { id } = await params
  try {
    const body = await req.json()
    // Delete existing recipe ingredients and replace
    await prisma.recipeIngredient.deleteMany({ where: { recipeId: id } })
    const recipe = await prisma.recipe.update({
      where: { id },
      data: {
        name: body.name,
        category: body.category,
        yield: body.yield ?? 1,
        sellingPrice: body.sellingPrice ?? 0,
        notes: body.notes ?? null,
        ingredients: {
          create: (body.ingredients ?? []).map((i: any) => ({
            quantity: i?.quantity ?? 0,
            ingredientId: i?.ingredientId,
          })),
        },
      },
      include: {
        ingredients: {
          include: { ingredient: { select: { id: true, name: true, costPerUnit: true, unit: true } } },
        },
      },
    })
    return NextResponse.json(recipe)
  } catch (error: any) {
    console.error('Update recipe error:', error)
    return NextResponse.json({ error: 'Error al actualizar receta' }, { status: 500 })
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('recipes:write')
  if ('error' in access) return access.error
  const { id } = await params
  try {
    await prisma.recipe.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete recipe error:', error)
    return NextResponse.json({ error: 'Error al eliminar receta' }, { status: 500 })
  }
}
