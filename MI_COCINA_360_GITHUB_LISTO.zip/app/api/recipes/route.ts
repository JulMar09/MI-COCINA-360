export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function GET() {
  const access = await requirePermission('recipes:read')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  const recipes = await prisma.recipe.findMany({
    where: { kitchenId: kitchen.id },
    orderBy: { name: 'asc' },
    include: {
      ingredients: {
        include: { ingredient: { select: { id: true, name: true, costPerUnit: true, unit: true } } },
      },
    },
  })
  // Calculate costs
  const recipesWithCosts = (recipes ?? []).map((r: any) => {
    const totalCost = (r?.ingredients ?? []).reduce(
      (sum: number, ri: any) => sum + (ri?.quantity ?? 0) * (ri?.ingredient?.costPerUnit ?? 0),
      0
    )
    const costPerPortion = totalCost / Math.max(r?.yield ?? 1, 1)
    const foodCostPercent = (r?.sellingPrice ?? 0) > 0
      ? (costPerPortion / (r?.sellingPrice ?? 1)) * 100
      : 0
    return {
      ...(r ?? {}),
      totalCost,
      costPerPortion,
      foodCostPercent,
    }
  })
  return NextResponse.json(recipesWithCosts)
}

export async function POST(req: Request) {
  const access = await requirePermission('recipes:write')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  try {
    const body = await req.json()
    if (!body.name || !body.category) {
      return NextResponse.json({ error: 'Nombre y categoría son obligatorios' }, { status: 400 })
    }
    const recipe = await prisma.recipe.create({
      data: {
        name: body.name,
        category: body.category,
        yield: body.yield ?? 1,
        sellingPrice: body.sellingPrice ?? 0,
        notes: body.notes ?? null,
        kitchenId: kitchen.id,
        ingredients: {
          create: (body.ingredients ?? []).map((i: any) => ({
            quantity: i?.quantity ?? 0,
            ingredientId: i?.ingredientId,
          })),
        },
      },
      include: {
        ingredients: {
          include: { ingredient: { select: { id: true, name: true, costPerUnit: true, unit: true } } },
        },
      },
    })
    return NextResponse.json(recipe, { status: 201 })
  } catch (error: any) {
    console.error('Create recipe error:', error)
    return NextResponse.json({ error: 'Error al crear receta' }, { status: 500 })
  }
}
