export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function GET(req: Request) {
  const access = await requirePermission('price_history:read')
  if ('error' in access) return access.error
  const kitchen = access.kitchen

  const { searchParams } = new URL(req.url)
  const ingredientId = searchParams.get('ingredientId')
  const dateFrom = searchParams.get('dateFrom')
  const dateTo = searchParams.get('dateTo')

  const where: any = {
    ingredient: { kitchenId: kitchen.id },
  }
  if (ingredientId) where.ingredientId = ingredientId
  if (dateFrom || dateTo) {
    where.date = {}
    if (dateFrom) where.date.gte = new Date(dateFrom)
    if (dateTo) {
      const end = new Date(dateTo)
      end.setHours(23, 59, 59, 999)
      where.date.lte = end
    }
  }

  const records = await prisma.ingredientPriceHistory.findMany({
    where,
    orderBy: { date: 'desc' },
    include: {
      ingredient: {
        select: {
          id: true,
          name: true,
          unit: true,
          supplierId: true,
          supplier: { select: { id: true, name: true } },
        },
      },
    },
  })

  // Group by ingredient to compute previous price
  const byIngredient = new Map<string, any[]>()
  for (const r of records) {
    const iid = r.ingredientId
    if (!byIngredient.has(iid)) byIngredient.set(iid, [])
    byIngredient.get(iid)!.push(r)
  }

  // If filtering by ingredient, we might not have the previous record.
  // Fetch the full history per ingredient to compute variations.
  // (For performance, only fetch for ingredients in our result set.)
  const ingredientIds = Array.from(byIngredient.keys())
  const allHistories = ingredientIds.length > 0
    ? await prisma.ingredientPriceHistory.findMany({
        where: {
          ingredientId: { in: ingredientIds },
          ingredient: { kitchenId: kitchen.id },
        },
        orderBy: { date: 'desc' },
      })
    : []

  const fullByIngredient = new Map<string, any[]>()
  for (const r of allHistories) {
    const iid = r.ingredientId
    if (!fullByIngredient.has(iid)) fullByIngredient.set(iid, [])
    fullByIngredient.get(iid)!.push(r)
  }

  // Also fetch delivery notes to match supplier info for albaran entries
  const deliveryNotes = await prisma.deliveryNote.findMany({
    where: { kitchenId: kitchen.id, ingredientId: { in: ingredientIds } },
    include: { supplier: { select: { name: true } } },
    orderBy: { date: 'desc' },
  })

  const enriched = records.map((entry: any) => {
    const fullHistory = fullByIngredient.get(entry.ingredientId) ?? []
    const idx = fullHistory.findIndex((h: any) => h.id === entry.id)
    const previousEntry = idx >= 0 && idx < fullHistory.length - 1 ? fullHistory[idx + 1] : null
    const previousPrice = previousEntry?.price ?? null
    const variationAbs = previousPrice !== null ? entry.price - previousPrice : null
    const variationPct = previousPrice !== null && previousPrice > 0
      ? ((entry.price - previousPrice) / previousPrice) * 100
      : null

    let supplierName: string | null = entry.ingredient?.supplier?.name ?? null
    if (entry.source === 'albaran') {
      const matchingNote = deliveryNotes.find(
        (dn: any) =>
          dn.ingredientId === entry.ingredientId &&
          Math.abs(new Date(dn.date).getTime() - new Date(entry.date).getTime()) < 60000
      )
      if (matchingNote?.supplier?.name) supplierName = matchingNote.supplier.name
    }

    return {
      id: entry.id,
      price: entry.price,
      date: entry.date,
      source: entry.source,
      ingredientId: entry.ingredientId,
      ingredientName: entry.ingredient?.name ?? '',
      ingredientUnit: entry.ingredient?.unit ?? '',
      previousPrice,
      variationAbs,
      variationPct,
      supplierName,
    }
  })

  // Also return list of ingredients for filter dropdown
  const ingredients = await prisma.ingredient.findMany({
    where: { kitchenId: kitchen.id },
    select: { id: true, name: true },
    orderBy: { name: 'asc' },
  })

  return NextResponse.json({ records: enriched, ingredients })
}
