export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/db'

export async function GET() {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const kitchens = await prisma.kitchen.findMany({ where: { userId: session.user.id } })
  return NextResponse.json(kitchens)
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  try {
    const { name, businessType, country, currency } = await req.json()
    if (!name || !businessType) {
      return NextResponse.json({ error: 'Nombre y tipo de negocio son obligatorios' }, { status: 400 })
    }
    const kitchen = await prisma.kitchen.create({
      data: {
        name,
        businessType,
        country: country || 'España',
        currency: currency || 'EUR',
        userId: session.user.id,
      },
    })
    return NextResponse.json(kitchen, { status: 201 })
  } catch (error: any) {
    console.error('Create kitchen error:', error)
    return NextResponse.json({ error: 'Error al crear la cocina' }, { status: 500 })
  }
}
