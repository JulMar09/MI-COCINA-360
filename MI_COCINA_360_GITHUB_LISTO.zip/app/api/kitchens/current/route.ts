export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/db'
import { getFoodCostConfig, validateFoodCostConfig } from '@/lib/food-cost'

export async function GET() {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  // Try KitchenMember first for role-aware access
  const member = await prisma.kitchenMember.findFirst({
    where: { userId: session.user.id, isActive: true },
    include: { kitchen: true },
    orderBy: { createdAt: 'desc' },
  })
  if (member) {
    return NextResponse.json({ ...member.kitchen, role: member.role })
  }
  // Fallback: direct ownership
  const kitchen = await prisma.kitchen.findFirst({
    where: { userId: session.user.id },
    orderBy: { createdAt: 'desc' },
  })
  if (!kitchen) return NextResponse.json(null, { status: 404 })
  return NextResponse.json({ ...kitchen, role: 'ADMIN' })
}

export async function PUT(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  // Get kitchen via membership or ownership
  const member = await prisma.kitchenMember.findFirst({
    where: { userId: session.user.id, isActive: true },
    include: { kitchen: true },
    orderBy: { createdAt: 'desc' },
  })
  const kitchen = member?.kitchen ?? await prisma.kitchen.findFirst({
    where: { userId: session.user.id },
    orderBy: { createdAt: 'desc' },
  })
  const role = member?.role ?? 'ADMIN'
  if (!kitchen) return NextResponse.json({ error: 'Sin cocina' }, { status: 404 })
  if (role !== 'ADMIN') return NextResponse.json({ error: 'Sin permisos' }, { status: 403 })
  try {
    const body = await req.json()

    // Construir la nueva configuración de rentabilidad partiendo de la actual
    // y aplicando solo los valores enviados.
    const current = getFoodCostConfig(kitchen)
    const nextConfig = {
      target: body.foodCostTarget !== undefined ? Number(body.foodCostTarget) : current.target,
      warning: body.foodCostWarning !== undefined ? Number(body.foodCostWarning) : current.warning,
      critical: body.foodCostCritical !== undefined ? Number(body.foodCostCritical) : current.critical,
    }

    // Validar solo cuando se intenta modificar la configuración de rentabilidad.
    const touchesFoodCost =
      body.foodCostTarget !== undefined ||
      body.foodCostWarning !== undefined ||
      body.foodCostCritical !== undefined
    if (touchesFoodCost) {
      const validationError = validateFoodCostConfig(nextConfig)
      if (validationError) {
        return NextResponse.json({ error: validationError }, { status: 400 })
      }
    }

    const updated = await prisma.kitchen.update({
      where: { id: kitchen.id },
      data: {
        name: body.name ?? kitchen.name,
        country: body.country ?? kitchen.country,
        currency: body.currency ?? kitchen.currency,
        foodCostTarget: nextConfig.target,
        foodCostWarning: nextConfig.warning,
        foodCostCritical: nextConfig.critical,
      },
    })
    return NextResponse.json(updated)
  } catch (error: any) {
    console.error('Update kitchen error:', error)
    return NextResponse.json({ error: 'Error al actualizar' }, { status: 500 })
  }
}
