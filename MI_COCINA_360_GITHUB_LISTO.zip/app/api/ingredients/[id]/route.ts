export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('ingredients:read')
  if ('error' in access) return access.error
  const { id } = await params
  const kitchen = access.kitchen
  try {
    const ingredient = await prisma.ingredient.findUnique({
      where: { id },
      include: {
        supplier: { select: { id: true, name: true } },
        priceHistory: {
          orderBy: { date: 'desc' },
        },
        deliveryNotes: {
          orderBy: { date: 'desc' },
          take: 10,
          include: { supplier: { select: { id: true, name: true } } },
        },
      },
    })
    if (!ingredient || ingredient.kitchenId !== kitchen.id) {
      return NextResponse.json({ error: 'Ingrediente no encontrado' }, { status: 404 })
    }
    // Enrich price history with previous price and variation
    const enrichedHistory = (ingredient.priceHistory ?? []).map((entry: any, idx: number, arr: any[]) => {
      const previousEntry = arr[idx + 1] // next in array = older record
      const previousPrice = previousEntry?.price ?? null
      const variationAbs = previousPrice !== null ? entry.price - previousPrice : null
      const variationPct = previousPrice !== null && previousPrice > 0
        ? ((entry.price - previousPrice) / previousPrice) * 100
        : null
      // Try to find a delivery note that matches this price change
      let supplierName: string | null = null
      if (entry.source === 'albaran') {
        const matchingNote = (ingredient.deliveryNotes ?? []).find(
          (dn: any) => Math.abs(new Date(dn.date).getTime() - new Date(entry.date).getTime()) < 60000
        )
        if (matchingNote?.supplier?.name) supplierName = matchingNote.supplier.name
      }
      return {
        id: entry.id,
        price: entry.price,
        date: entry.date,
        source: entry.source,
        previousPrice,
        variationAbs,
        variationPct,
        supplierName,
      }
    })
    return NextResponse.json({
      ...ingredient,
      priceHistory: enrichedHistory,
    })
  } catch (error: any) {
    console.error('Get ingredient detail error:', error)
    return NextResponse.json({ error: 'Error al obtener ingrediente' }, { status: 500 })
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('ingredients:write')
  if ('error' in access) return access.error
  const { id } = await params
  try {
    const body = await req.json()
    const existing = await prisma.ingredient.findUnique({ where: { id } })
    if (!existing) return NextResponse.json({ error: 'Ingrediente no encontrado' }, { status: 404 })
    
    const priceChanged = body.costPerUnit !== undefined && body.costPerUnit !== existing.costPerUnit
    
    const ingredient = await prisma.ingredient.update({
      where: { id },
      data: {
        name: body.name ?? existing.name,
        category: body.category ?? existing.category,
        unit: body.unit ?? existing.unit,
        costPerUnit: body.costPerUnit ?? existing.costPerUnit,
        targetStock: body.targetStock ?? existing.targetStock,
        minStock: body.minStock ?? existing.minStock,
        criticalStock: body.criticalStock ?? existing.criticalStock,
        currentStock: body.currentStock ?? existing.currentStock,
        notes: body.notes !== undefined ? body.notes : existing.notes,
        supplierId: body.supplierId !== undefined ? (body.supplierId || null) : existing.supplierId,
      },
    })
    
    if (priceChanged) {
      await prisma.ingredientPriceHistory.create({
        data: {
          price: body.costPerUnit,
          source: 'manual',
          ingredientId: id,
        },
      })
    }
    
    return NextResponse.json(ingredient)
  } catch (error: any) {
    console.error('Update ingredient error:', error)
    return NextResponse.json({ error: 'Error al actualizar ingrediente' }, { status: 500 })
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('ingredients:write')
  if ('error' in access) return access.error
  const { id } = await params
  try {
    await prisma.ingredient.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete ingredient error:', error)
    return NextResponse.json({ error: 'Error al eliminar ingrediente' }, { status: 500 })
  }
}
