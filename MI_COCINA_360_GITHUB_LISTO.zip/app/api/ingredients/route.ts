export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function GET() {
  const access = await requirePermission('ingredients:read')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  const ingredients = await prisma.ingredient.findMany({
    where: { kitchenId: kitchen.id },
    orderBy: { name: 'asc' },
    include: { supplier: { select: { id: true, name: true } } },
  })
  return NextResponse.json(ingredients)
}

export async function POST(req: Request) {
  const access = await requirePermission('ingredients:write')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  try {
    const body = await req.json()
    if (!body.name || !body.category || !body.unit) {
      return NextResponse.json({ error: 'Nombre, categoría y unidad son obligatorios' }, { status: 400 })
    }
    const ingredient = await prisma.ingredient.create({
      data: {
        name: body.name,
        category: body.category,
        unit: body.unit,
        costPerUnit: body.costPerUnit ?? 0,
        targetStock: body.targetStock ?? 0,
        minStock: body.minStock ?? 0,
        criticalStock: body.criticalStock ?? 0,
        currentStock: body.currentStock ?? 0,
        notes: body.notes ?? null,
        supplierId: body.supplierId || null,
        kitchenId: kitchen.id,
      },
    })
    // Record initial price
    if ((body.costPerUnit ?? 0) > 0) {
      await prisma.ingredientPriceHistory.create({
        data: {
          price: body.costPerUnit,
          source: 'initial',
          ingredientId: ingredient.id,
        },
      })
    }
    return NextResponse.json(ingredient, { status: 201 })
  } catch (error: any) {
    console.error('Create ingredient error:', error)
    return NextResponse.json({ error: 'Error al crear ingrediente' }, { status: 500 })
  }
}
