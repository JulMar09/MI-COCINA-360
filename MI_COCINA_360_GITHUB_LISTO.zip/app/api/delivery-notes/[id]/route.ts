export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('delivery_notes:write')
  if (access instanceof NextResponse) return access
  const { id } = await params
  try {
    await prisma.deliveryNote.delete({ where: { id, kitchenId: access.kitchenId } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete delivery note error:', error)
    return NextResponse.json({ error: 'Error al eliminar albarán' }, { status: 500 })
  }
}
