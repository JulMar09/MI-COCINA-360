export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function GET() {
  const access = await requirePermission('delivery_notes:read')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  const notes = await prisma.deliveryNote.findMany({
    where: { kitchenId: kitchen.id },
    orderBy: { date: 'desc' },
    include: {
      supplier: { select: { id: true, name: true } },
      ingredient: { select: { id: true, name: true, unit: true } },
    },
  })
  return NextResponse.json(notes)
}

export async function POST(req: Request) {
  const access = await requirePermission('delivery_notes:write')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  try {
    const body = await req.json()
    if (!body.supplierId || !body.ingredientId) {
      return NextResponse.json({ error: 'Proveedor e ingrediente son obligatorios' }, { status: 400 })
    }
    const totalPrice = (body.quantity ?? 0) * (body.unitPrice ?? 0)
    const note = await prisma.deliveryNote.create({
      data: {
        date: body.date ? new Date(body.date) : new Date(),
        quantity: body.quantity ?? 0,
        unit: body.unit ?? '',
        unitPrice: body.unitPrice ?? 0,
        totalPrice,
        notes: body.notes ?? null,
        supplierId: body.supplierId,
        ingredientId: body.ingredientId,
        kitchenId: kitchen.id,
      },
      include: {
        supplier: { select: { id: true, name: true } },
        ingredient: { select: { id: true, name: true, unit: true } },
      },
    })

    // Update ingredient price and stock
    const ingredient = await prisma.ingredient.findUnique({ where: { id: body.ingredientId } })
    if (ingredient) {
      const priceChanged = body.unitPrice !== undefined && body.unitPrice !== ingredient.costPerUnit
      await prisma.ingredient.update({
        where: { id: body.ingredientId },
        data: {
          costPerUnit: body.unitPrice ?? ingredient.costPerUnit,
          currentStock: { increment: body.quantity ?? 0 },
        },
      })
      if (priceChanged) {
        await prisma.ingredientPriceHistory.create({
          data: {
            price: body.unitPrice,
            source: 'albaran',
            ingredientId: body.ingredientId,
          },
        })
      }
    }

    return NextResponse.json(note, { status: 201 })
  } catch (error: any) {
    console.error('Create delivery note error:', error)
    return NextResponse.json({ error: 'Error al crear albarán' }, { status: 500 })
  }
}
