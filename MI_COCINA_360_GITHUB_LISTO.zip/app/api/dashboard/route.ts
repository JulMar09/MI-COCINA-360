export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { getFoodCostConfig } from '@/lib/food-cost'
import { buildRecipeCosts, computeAlerts } from '@/lib/alerts'
import { requirePermission } from '@/lib/permissions'

export async function GET() {
  const access = await requirePermission('dashboard:read')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  const kitchenId = kitchen.id
  const foodCostConfig = getFoodCostConfig(kitchen)

  const [ingredientCount, supplierCount, recipeCount, allIngredients, allRecipes, recentPriceChanges] = await Promise.all([
    prisma.ingredient.count({ where: { kitchenId } }),
    prisma.supplier.count({ where: { kitchenId } }),
    prisma.recipe.count({ where: { kitchenId } }),
    prisma.ingredient.findMany({
      where: { kitchenId },
      include: { supplier: { select: { name: true } } },
    }),
    prisma.recipe.findMany({
      where: { kitchenId },
      include: {
        ingredients: {
          include: { ingredient: { select: { costPerUnit: true, name: true } } },
        },
      },
    }),
    prisma.ingredientPriceHistory.findMany({
      where: { ingredient: { kitchenId } },
      include: { ingredient: { select: { name: true, unit: true } } },
      orderBy: { date: 'desc' },
      take: 20,
    }),
  ])

  // Inventory value
  const inventoryValue = (allIngredients ?? []).reduce(
    (sum: number, i: any) => sum + (i?.currentStock ?? 0) * (i?.costPerUnit ?? 0),
    0
  )

  // Recipe costs (fuente única en lib/alerts)
  const recipeCosts = buildRecipeCosts(allRecipes ?? [])

  // --- ALERTS (Estado de la cocina) ---
  // Misma lógica exacta que usa el Centro de alertas (lib/alerts).
  const alerts = computeAlerts({
    allIngredients: allIngredients ?? [],
    recipeCosts,
    priceHistory: recentPriceChanges ?? [],
    foodCostConfig,
  })

  // --- HOY EN TU COCINA ---
  const today = new Date()
  const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate())
  const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000)

  const [todayDeliveryNotes, recentDeliveryNotes] = await Promise.all([
    prisma.deliveryNote.findMany({
      where: { kitchenId, date: { gte: startOfDay, lt: endOfDay } },
      include: { supplier: { select: { name: true } }, ingredient: { select: { name: true } } },
      orderBy: { date: 'desc' },
    }),
    prisma.deliveryNote.findMany({
      where: { kitchenId },
      include: { supplier: { select: { name: true } }, ingredient: { select: { name: true } } },
      orderBy: { date: 'desc' },
      take: 5,
    }),
  ])

  const lowStockCount = (allIngredients ?? []).filter(
    (i: any) => (i?.minStock ?? 0) > 0 && (i?.currentStock ?? 0) < (i?.minStock ?? 0)
  ).length

  const todaySection = {
    todayDeliveryNotes: (todayDeliveryNotes ?? []).map((dn: any) => ({
      id: dn?.id,
      supplierName: dn?.supplier?.name ?? '',
      ingredientName: dn?.ingredient?.name ?? '',
      quantity: dn?.quantity ?? 0,
      unit: dn?.unit ?? '',
      totalPrice: dn?.totalPrice ?? 0,
    })),
    recentDeliveryNotes: (recentDeliveryNotes ?? []).map((dn: any) => ({
      id: dn?.id,
      date: dn?.date,
      supplierName: dn?.supplier?.name ?? '',
      ingredientName: dn?.ingredient?.name ?? '',
      quantity: dn?.quantity ?? 0,
      unit: dn?.unit ?? '',
      totalPrice: dn?.totalPrice ?? 0,
    })),
    lowStockCount,
    alertCount: alerts.filter((a: any) => (a?.severity === 'critical' || a?.severity === 'warning')).length,
    totalIngredients: ingredientCount,
    totalRecipes: recipeCount,
  }

  return NextResponse.json({
    ingredientCount,
    supplierCount,
    recipeCount,
    inventoryValue,
    topRecipes: recipeCosts.slice(0, 5),
    recentPriceChanges: (recentPriceChanges ?? []).slice(0, 10).map((p: any) => ({
      id: p?.id,
      ingredientName: p?.ingredient?.name ?? '',
      unit: p?.ingredient?.unit ?? '',
      price: p?.price ?? 0,
      date: p?.date,
      source: p?.source ?? 'manual',
    })),
    currency: kitchen.currency,
    alerts,
    today: todaySection,
  })
}
