export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { analyzeStock } from '@/lib/stock-levels'
import { requirePermission } from '@/lib/permissions'

export async function GET() {
  const access = await requirePermission('shopping_list:read')
  if ('error' in access) return access.error
  const kitchen = access.kitchen

  const [ingredients, shoppingItems] = await Promise.all([
    prisma.ingredient.findMany({
      where: { kitchenId: kitchen.id },
      include: { supplier: { select: { id: true, name: true } } },
      orderBy: { name: 'asc' },
    }),
    prisma.shoppingListItem.findMany({
      where: { kitchenId: kitchen.id },
    }),
  ])

  // Build a map of shopping status by ingredientId
  const statusMap = new Map<string, { status: string; quantity: number; purchasedAt: Date | null }>()
  for (const item of shoppingItems) {
    statusMap.set(item.ingredientId, {
      status: item.status,
      quantity: item.quantity,
      purchasedAt: item.purchasedAt,
    })
  }

  // Analyze each ingredient and include those needing purchase OR already marked purchased
  const results = []
  for (const ing of ingredients) {
    const analysis = analyzeStock({
      currentStock: ing.currentStock,
      criticalStock: ing.criticalStock,
      minStock: ing.minStock,
      targetStock: ing.targetStock,
    })

    const shopInfo = statusMap.get(ing.id)
    const needsPurchase = analysis.suggestedPurchase > 0
    const isPurchased = shopInfo?.status === 'purchased'

    // Show if needs purchase OR is already marked as purchased (so user can see it)
    if (needsPurchase || isPurchased) {
      results.push({
        id: ing.id,
        name: ing.name,
        category: ing.category,
        unit: ing.unit,
        currentStock: ing.currentStock,
        targetStock: ing.targetStock,
        costPerUnit: ing.costPerUnit,
        suggestedPurchase: analysis.suggestedPurchase,
        stockLevel: analysis.levelInfo.level,
        stockLevelLabel: analysis.levelInfo.label,
        stockLevelColor: analysis.levelInfo.color,
        supplier: ing.supplier,
        status: isPurchased ? 'purchased' : 'pending',
        purchasedAt: shopInfo?.purchasedAt ?? null,
      })
    }
  }

  // Sort: pending first (critical > bajo > normal), then purchased
  const levelOrder: Record<string, number> = { critico: 0, bajo: 1, normal: 2, optimo: 3, sin_configurar: 4 }
  results.sort((a, b) => {
    if (a.status !== b.status) return a.status === 'pending' ? -1 : 1
    return (levelOrder[a.stockLevel] ?? 4) - (levelOrder[b.stockLevel] ?? 4)
  })

  return NextResponse.json(results)
}
