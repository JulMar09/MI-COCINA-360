export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function POST(req: Request) {
  const access = await requirePermission('shopping_list:write')
  if ('error' in access) return access.error
  const kitchen = access.kitchen

  try {
    const body = await req.json()
    const { ingredientId, status } = body

    if (!ingredientId || !['pending', 'purchased'].includes(status)) {
      return NextResponse.json({ error: 'Datos inválidos' }, { status: 400 })
    }

    // Verify ingredient belongs to this kitchen
    const ingredient = await prisma.ingredient.findFirst({
      where: { id: ingredientId, kitchenId: kitchen.id },
    })
    if (!ingredient) {
      return NextResponse.json({ error: 'Ingrediente no encontrado' }, { status: 404 })
    }

    const result = await prisma.shoppingListItem.upsert({
      where: {
        kitchenId_ingredientId: {
          kitchenId: kitchen.id,
          ingredientId,
        },
      },
      create: {
        kitchenId: kitchen.id,
        ingredientId,
        quantity: ingredient.targetStock > 0 ? Math.max(0, ingredient.targetStock - ingredient.currentStock) : 0,
        status,
        purchasedAt: status === 'purchased' ? new Date() : null,
      },
      update: {
        status,
        purchasedAt: status === 'purchased' ? new Date() : null,
      },
    })

    return NextResponse.json(result)
  } catch (error: any) {
    console.error('Toggle shopping item error:', error)
    return NextResponse.json({ error: 'Error al actualizar' }, { status: 500 })
  }
}
