export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

// PUT: update member role or active status
export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('users:write')
  if ('error' in access) return access.error
  const { id } = await params
  try {
    const body = await req.json()
    const member = await prisma.kitchenMember.findFirst({
      where: { id, kitchenId: access.kitchen.id },
    })
    if (!member) return NextResponse.json({ error: 'Miembro no encontrado' }, { status: 404 })
    // Cannot deactivate or change role of kitchen owner
    if (member.userId === (access.kitchen as any).userId && (body.isActive === false || (body.role && body.role !== 'ADMIN'))) {
      return NextResponse.json({ error: 'No puedes modificar al propietario de la cocina' }, { status: 403 })
    }
    const validRoles = ['ADMIN', 'ENCARGADO', 'COCINERO', 'CONSULTA']
    if (body.role && !validRoles.includes(body.role)) {
      return NextResponse.json({ error: 'Rol inv\u00e1lido' }, { status: 400 })
    }
    const updated = await prisma.kitchenMember.update({
      where: { id },
      data: {
        ...(body.role !== undefined ? { role: body.role } : {}),
        ...(body.isActive !== undefined ? { isActive: body.isActive } : {}),
      },
    })
    return NextResponse.json(updated)
  } catch (error: any) {
    console.error('Update member error:', error)
    return NextResponse.json({ error: 'Error al actualizar miembro' }, { status: 500 })
  }
}
