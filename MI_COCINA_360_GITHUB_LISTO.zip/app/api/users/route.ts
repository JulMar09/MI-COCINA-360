export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import bcrypt from 'bcryptjs'

// GET: list members of the current kitchen
export async function GET() {
  const access = await requirePermission('users:read')
  if ('error' in access) return access.error
  const members = await prisma.kitchenMember.findMany({
    where: { kitchenId: access.kitchen.id },
    include: { user: { select: { id: true, name: true, email: true, createdAt: true } } },
    orderBy: { createdAt: 'asc' },
  })
  return NextResponse.json(members.map(m => ({
    id: m.id,
    userId: m.userId,
    name: m.user.name,
    email: m.user.email,
    role: m.role,
    isActive: m.isActive,
    createdAt: m.createdAt,
    userCreatedAt: m.user.createdAt,
  })))
}

// POST: invite a new user to the kitchen
export async function POST(req: Request) {
  const access = await requirePermission('users:write')
  if ('error' in access) return access.error
  try {
    const { email, name, password, role } = await req.json()
    if (!email || !password || !role) {
      return NextResponse.json({ error: 'Email, contrase\u00f1a y rol son obligatorios' }, { status: 400 })
    }
    const validRoles = ['ADMIN', 'ENCARGADO', 'COCINERO', 'CONSULTA']
    if (!validRoles.includes(role)) {
      return NextResponse.json({ error: 'Rol inv\u00e1lido' }, { status: 400 })
    }
    // Check if user already exists
    let user = await prisma.user.findFirst({ where: { email: { equals: email.trim(), mode: 'insensitive' } } })
    if (!user) {
      const hash = await bcrypt.hash(password, 12)
      user = await prisma.user.create({ data: { email: email.trim().toLowerCase(), name: name || null, password: hash } })
    }
    // Check if already member
    const existing = await prisma.kitchenMember.findUnique({
      where: { userId_kitchenId: { userId: user.id, kitchenId: access.kitchen.id } }
    })
    if (existing) {
      return NextResponse.json({ error: 'Este usuario ya pertenece a la cocina' }, { status: 409 })
    }
    const member = await prisma.kitchenMember.create({
      data: { userId: user.id, kitchenId: access.kitchen.id, role },
    })
    return NextResponse.json({ ...member, name: user.name, email: user.email }, { status: 201 })
  } catch (error: any) {
    console.error('Invite user error:', error)
    return NextResponse.json({ error: 'Error al a\u00f1adir usuario' }, { status: 500 })
  }
}
