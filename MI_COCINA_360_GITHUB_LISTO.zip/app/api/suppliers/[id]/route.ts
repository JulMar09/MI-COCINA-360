export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('suppliers:write')
  if ('error' in access) return access.error
  const { id } = await params
  try {
    const body = await req.json()
    const supplier = await prisma.supplier.update({
      where: { id },
      data: {
        name: body.name,
        contactPerson: body.contactPerson,
        phone: body.phone,
        email: body.email,
        notes: body.notes,
      },
    })
    return NextResponse.json(supplier)
  } catch (error: any) {
    console.error('Update supplier error:', error)
    return NextResponse.json({ error: 'Error al actualizar proveedor' }, { status: 500 })
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const access = await requirePermission('suppliers:write')
  if ('error' in access) return access.error
  const { id } = await params
  try {
    await prisma.supplier.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete supplier error:', error)
    return NextResponse.json({ error: 'Error al eliminar proveedor' }, { status: 500 })
  }
}
