export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'

export async function GET() {
  const access = await requirePermission('suppliers:read')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  const suppliers = await prisma.supplier.findMany({
    where: { kitchenId: kitchen.id },
    orderBy: { name: 'asc' },
    include: { _count: { select: { ingredients: true, deliveryNotes: true } } },
  })
  return NextResponse.json(suppliers)
}

export async function POST(req: Request) {
  const access = await requirePermission('suppliers:write')
  if ('error' in access) return access.error
  const kitchen = access.kitchen
  try {
    const { name, contactPerson, phone, email, notes } = await req.json()
    if (!name) return NextResponse.json({ error: 'Nombre es obligatorio' }, { status: 400 })
    const supplier = await prisma.supplier.create({
      data: { name, contactPerson, phone, email, notes, kitchenId: kitchen.id },
    })
    return NextResponse.json(supplier, { status: 201 })
  } catch (error: any) {
    console.error('Create supplier error:', error)
    return NextResponse.json({ error: 'Error al crear proveedor' }, { status: 500 })
  }
}
