export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/db'

export async function GET() {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const kitchen = await prisma.kitchen.findFirst({ where: { userId: session.user.id } })
  if (!kitchen) return NextResponse.json([])
  const ingredients = await prisma.ingredient.findMany({
    where: { kitchenId: kitchen.id },
    orderBy: { name: 'asc' },
    include: { supplier: { select: { id: true, name: true } } },
  })
  return NextResponse.json(ingredients)
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const kitchen = await prisma.kitchen.findFirst({ where: { userId: session.user.id } })
  if (!kitchen) return NextResponse.json({ error: 'Sin cocina' }, { status: 404 })
  try {
    const body = await req.json()
    if (!body.name || !body.category || !body.unit) {
      return NextResponse.json({ error: 'Nombre, categoría y unidad son obligatorios' }, { status: 400 })
    }
    const ingredient = await prisma.ingredient.create({
      data: {
        name: body.name,
        category: body.category,
        unit: body.unit,
        costPerUnit: body.costPerUnit ?? 0,
        minStock: body.minStock ?? 0,
        currentStock: body.currentStock ?? 0,
        notes: body.notes ?? null,
        supplierId: body.supplierId || null,
        kitchenId: kitchen.id,
      },
    })
    // Record initial price
    if ((body.costPerUnit ?? 0) > 0) {
      await prisma.ingredientPriceHistory.create({
        data: {
          price: body.costPerUnit,
          source: 'initial',
          ingredientId: ingredient.id,
        },
      })
    }
    return NextResponse.json(ingredient, { status: 201 })
  } catch (error: any) {
    console.error('Create ingredient error:', error)
    return NextResponse.json({ error: 'Error al crear ingrediente' }, { status: 500 })
  }
}
