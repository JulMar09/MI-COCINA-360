export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/db'

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const { id } = await params
  try {
    const body = await req.json()
    const existing = await prisma.ingredient.findUnique({ where: { id } })
    if (!existing) return NextResponse.json({ error: 'Ingrediente no encontrado' }, { status: 404 })
    
    const priceChanged = body.costPerUnit !== undefined && body.costPerUnit !== existing.costPerUnit
    
    const ingredient = await prisma.ingredient.update({
      where: { id },
      data: {
        name: body.name ?? existing.name,
        category: body.category ?? existing.category,
        unit: body.unit ?? existing.unit,
        costPerUnit: body.costPerUnit ?? existing.costPerUnit,
        minStock: body.minStock ?? existing.minStock,
        currentStock: body.currentStock ?? existing.currentStock,
        notes: body.notes !== undefined ? body.notes : existing.notes,
        supplierId: body.supplierId !== undefined ? (body.supplierId || null) : existing.supplierId,
      },
    })
    
    if (priceChanged) {
      await prisma.ingredientPriceHistory.create({
        data: {
          price: body.costPerUnit,
          source: 'manual',
          ingredientId: id,
        },
      })
    }
    
    return NextResponse.json(ingredient)
  } catch (error: any) {
    console.error('Update ingredient error:', error)
    return NextResponse.json({ error: 'Error al actualizar ingrediente' }, { status: 500 })
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const { id } = await params
  try {
    await prisma.ingredient.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete ingredient error:', error)
    return NextResponse.json({ error: 'Error al eliminar ingrediente' }, { status: 500 })
  }
}
