export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/db'

const FOOD_COST_TARGET = 33 // percentage threshold

export async function GET() {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  
  const kitchen = await prisma.kitchen.findFirst({ where: { userId: session.user.id } })
  if (!kitchen) return NextResponse.json({ error: 'Sin cocina' }, { status: 404 })
  const kitchenId = kitchen.id

  const [ingredientCount, supplierCount, recipeCount, allIngredients, allRecipes, recentPriceChanges] = await Promise.all([
    prisma.ingredient.count({ where: { kitchenId } }),
    prisma.supplier.count({ where: { kitchenId } }),
    prisma.recipe.count({ where: { kitchenId } }),
    prisma.ingredient.findMany({
      where: { kitchenId },
      include: { supplier: { select: { name: true } } },
    }),
    prisma.recipe.findMany({
      where: { kitchenId },
      include: {
        ingredients: {
          include: { ingredient: { select: { costPerUnit: true, name: true } } },
        },
      },
    }),
    prisma.ingredientPriceHistory.findMany({
      where: { ingredient: { kitchenId } },
      include: { ingredient: { select: { name: true, unit: true } } },
      orderBy: { date: 'desc' },
      take: 20,
    }),
  ])

  // Inventory value
  const inventoryValue = (allIngredients ?? []).reduce(
    (sum: number, i: any) => sum + (i?.currentStock ?? 0) * (i?.costPerUnit ?? 0),
    0
  )

  // Recipe costs
  const recipeCosts = (allRecipes ?? []).map((r: any) => {
    const totalCost = (r?.ingredients ?? []).reduce(
      (sum: number, ri: any) => sum + (ri?.quantity ?? 0) * (ri?.ingredient?.costPerUnit ?? 0),
      0
    )
    const costPerPortion = totalCost / Math.max(r?.yield ?? 1, 1)
    const foodCostPct = (r?.sellingPrice ?? 0) > 0
      ? (costPerPortion / r.sellingPrice) * 100
      : 0
    return {
      id: r?.id,
      name: r?.name ?? '',
      category: r?.category ?? '',
      yield: r?.yield ?? 1,
      sellingPrice: r?.sellingPrice ?? 0,
      totalCost,
      costPerPortion,
      foodCostPct,
    }
  })
  recipeCosts.sort((a: any, b: any) => (b?.totalCost ?? 0) - (a?.totalCost ?? 0))

  // --- ALERTS (Estado de la cocina) ---
  const alerts: any[] = []

  // 1. Low-stock ingredients
  for (const ing of (allIngredients ?? [])) {
    if ((ing?.minStock ?? 0) > 0 && (ing?.currentStock ?? 0) < (ing?.minStock ?? 0)) {
      alerts.push({
        type: 'stock_bajo',
        severity: (ing?.currentStock ?? 0) === 0 ? 'critical' : 'warning',
        title: `Stock bajo: ${ing?.name ?? ''}`,
        description: `Stock actual: ${ing?.currentStock ?? 0} ${ing?.unit ?? ''} (mínimo: ${ing?.minStock ?? 0} ${ing?.unit ?? ''})`,
        elementId: ing?.id,
        href: '/ingredients',
        date: new Date().toISOString(),
      })
    }
  }

  // 2. High food cost recipes
  for (const recipe of recipeCosts) {
    if ((recipe?.sellingPrice ?? 0) > 0 && (recipe?.foodCostPct ?? 0) > FOOD_COST_TARGET) {
      const severity = (recipe?.foodCostPct ?? 0) > 45 ? 'critical' : 'warning'
      alerts.push({
        type: 'food_cost_alto',
        severity,
        title: `Food Cost elevado: ${recipe?.name ?? ''}`,
        description: `Food Cost: ${(recipe?.foodCostPct ?? 0).toFixed(1)}% (objetivo: <${FOOD_COST_TARGET}%)`,
        elementId: recipe?.id,
        href: '/recipes',
        date: new Date().toISOString(),
      })
    }
  }

  // 3. Significant price changes (>15% variation between last two prices for same ingredient)
  const priceByIngredient = new Map<string, any[]>()
  for (const ph of (recentPriceChanges ?? [])) {
    const iid = ph?.ingredientId ?? ''
    if (!priceByIngredient.has(iid)) priceByIngredient.set(iid, [])
    priceByIngredient.get(iid)!.push(ph)
  }
  for (const [, history] of priceByIngredient) {
    if (history.length >= 2) {
      const latest = history[0]
      const previous = history[1]
      const oldPrice = previous?.price ?? 0
      const newPrice = latest?.price ?? 0
      if (oldPrice > 0) {
        const variation = ((newPrice - oldPrice) / oldPrice) * 100
        if (Math.abs(variation) > 15) {
          alerts.push({
            type: 'cambio_precio',
            severity: Math.abs(variation) > 30 ? 'critical' : 'warning',
            title: `Cambio de precio: ${latest?.ingredient?.name ?? ''}`,
            description: `${variation > 0 ? '+' : ''}${variation.toFixed(1)}% (de ${oldPrice.toFixed(2)} a ${newPrice.toFixed(2)}€/${latest?.ingredient?.unit ?? ''})`,
            elementId: latest?.ingredientId,
            href: '/ingredients',
            date: latest?.date,
          })
        }
      }
    }
  }

  // 4. Ingredients with zero cost (potential data issue)
  for (const ing of (allIngredients ?? [])) {
    if ((ing?.costPerUnit ?? 0) === 0 && (ing?.currentStock ?? 0) > 0) {
      alerts.push({
        type: 'sin_precio',
        severity: 'info',
        title: `Sin precio: ${ing?.name ?? ''}`,
        description: `Este ingrediente tiene stock pero no tiene precio registrado`,
        elementId: ing?.id,
        href: '/ingredients',
        date: new Date().toISOString(),
      })
    }
  }

  // Sort alerts: critical first, then warning, then info
  const severityOrder: Record<string, number> = { critical: 0, warning: 1, info: 2 }
  alerts.sort((a, b) => (severityOrder[a?.severity] ?? 2) - (severityOrder[b?.severity] ?? 2))

  // --- HOY EN TU COCINA ---
  const today = new Date()
  const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate())
  const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000)

  const [todayDeliveryNotes, recentDeliveryNotes] = await Promise.all([
    prisma.deliveryNote.findMany({
      where: { kitchenId, date: { gte: startOfDay, lt: endOfDay } },
      include: { supplier: { select: { name: true } }, ingredient: { select: { name: true } } },
      orderBy: { date: 'desc' },
    }),
    prisma.deliveryNote.findMany({
      where: { kitchenId },
      include: { supplier: { select: { name: true } }, ingredient: { select: { name: true } } },
      orderBy: { date: 'desc' },
      take: 5,
    }),
  ])

  const lowStockCount = (allIngredients ?? []).filter(
    (i: any) => (i?.minStock ?? 0) > 0 && (i?.currentStock ?? 0) < (i?.minStock ?? 0)
  ).length

  const todaySection = {
    todayDeliveryNotes: (todayDeliveryNotes ?? []).map((dn: any) => ({
      id: dn?.id,
      supplierName: dn?.supplier?.name ?? '',
      ingredientName: dn?.ingredient?.name ?? '',
      quantity: dn?.quantity ?? 0,
      unit: dn?.unit ?? '',
      totalPrice: dn?.totalPrice ?? 0,
    })),
    recentDeliveryNotes: (recentDeliveryNotes ?? []).map((dn: any) => ({
      id: dn?.id,
      date: dn?.date,
      supplierName: dn?.supplier?.name ?? '',
      ingredientName: dn?.ingredient?.name ?? '',
      quantity: dn?.quantity ?? 0,
      unit: dn?.unit ?? '',
      totalPrice: dn?.totalPrice ?? 0,
    })),
    lowStockCount,
    alertCount: alerts.filter((a: any) => (a?.severity === 'critical' || a?.severity === 'warning')).length,
    totalIngredients: ingredientCount,
    totalRecipes: recipeCount,
  }

  return NextResponse.json({
    ingredientCount,
    supplierCount,
    recipeCount,
    inventoryValue,
    topRecipes: recipeCosts.slice(0, 5),
    recentPriceChanges: (recentPriceChanges ?? []).slice(0, 10).map((p: any) => ({
      id: p?.id,
      ingredientName: p?.ingredient?.name ?? '',
      unit: p?.ingredient?.unit ?? '',
      price: p?.price ?? 0,
      date: p?.date,
      source: p?.source ?? 'manual',
    })),
    currency: kitchen.currency,
    alerts,
    today: todaySection,
  })
}
