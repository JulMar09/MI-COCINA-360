export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/db'

export async function GET() {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const kitchen = await prisma.kitchen.findFirst({
    where: { userId: session.user.id },
    orderBy: { createdAt: 'desc' },
  })
  if (!kitchen) return NextResponse.json(null, { status: 404 })
  return NextResponse.json(kitchen)
}

export async function PUT(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const kitchen = await prisma.kitchen.findFirst({
    where: { userId: session.user.id },
    orderBy: { createdAt: 'desc' },
  })
  if (!kitchen) return NextResponse.json({ error: 'Sin cocina' }, { status: 404 })
  try {
    const body = await req.json()
    const updated = await prisma.kitchen.update({
      where: { id: kitchen.id },
      data: {
        name: body.name ?? kitchen.name,
        country: body.country ?? kitchen.country,
        currency: body.currency ?? kitchen.currency,
      },
    })
    return NextResponse.json(updated)
  } catch (error: any) {
    console.error('Update kitchen error:', error)
    return NextResponse.json({ error: 'Error al actualizar' }, { status: 500 })
  }
}
