export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/db'

export async function GET() {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const kitchen = await prisma.kitchen.findFirst({ where: { userId: session.user.id } })
  if (!kitchen) return NextResponse.json([])
  const suppliers = await prisma.supplier.findMany({
    where: { kitchenId: kitchen.id },
    orderBy: { name: 'asc' },
    include: { _count: { select: { ingredients: true, deliveryNotes: true } } },
  })
  return NextResponse.json(suppliers)
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const kitchen = await prisma.kitchen.findFirst({ where: { userId: session.user.id } })
  if (!kitchen) return NextResponse.json({ error: 'Sin cocina' }, { status: 404 })
  try {
    const { name, contactPerson, phone, email, notes } = await req.json()
    if (!name) return NextResponse.json({ error: 'Nombre es obligatorio' }, { status: 400 })
    const supplier = await prisma.supplier.create({
      data: { name, contactPerson, phone, email, notes, kitchenId: kitchen.id },
    })
    return NextResponse.json(supplier, { status: 201 })
  } catch (error: any) {
    console.error('Create supplier error:', error)
    return NextResponse.json({ error: 'Error al crear proveedor' }, { status: 500 })
  }
}
