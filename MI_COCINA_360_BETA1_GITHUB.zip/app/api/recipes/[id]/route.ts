export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/db'

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const { id } = await params
  try {
    const body = await req.json()
    // Delete existing recipe ingredients and replace
    await prisma.recipeIngredient.deleteMany({ where: { recipeId: id } })
    const recipe = await prisma.recipe.update({
      where: { id },
      data: {
        name: body.name,
        category: body.category,
        yield: body.yield ?? 1,
        sellingPrice: body.sellingPrice ?? 0,
        notes: body.notes ?? null,
        ingredients: {
          create: (body.ingredients ?? []).map((i: any) => ({
            quantity: i?.quantity ?? 0,
            ingredientId: i?.ingredientId,
          })),
        },
      },
      include: {
        ingredients: {
          include: { ingredient: { select: { id: true, name: true, costPerUnit: true, unit: true } } },
        },
      },
    })
    return NextResponse.json(recipe)
  } catch (error: any) {
    console.error('Update recipe error:', error)
    return NextResponse.json({ error: 'Error al actualizar receta' }, { status: 500 })
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
  const { id } = await params
  try {
    await prisma.recipe.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete recipe error:', error)
    return NextResponse.json({ error: 'Error al eliminar receta' }, { status: 500 })
  }
}
