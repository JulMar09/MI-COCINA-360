'use client'

import { useState, useEffect } from 'react'
import { useKitchen } from '@/lib/kitchen-context'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { FadeIn } from '@/components/ui/animate'
import { Settings, Building2 } from 'lucide-react'
import { toast } from 'sonner'

const CURRENCIES = [
  { value: 'EUR', label: '€ Euro (EUR)' },
  { value: 'USD', label: '$ Dólar (USD)' },
  { value: 'GBP', label: '£ Libra (GBP)' },
  { value: 'MXN', label: '$ Peso MX (MXN)' },
]

export function SettingsClient() {
  const { kitchen, refresh } = useKitchen()
  const [name, setName] = useState('')
  const [country, setCountry] = useState('')
  const [currency, setCurrency] = useState('EUR')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (kitchen) {
      setName(kitchen.name ?? '')
      setCountry(kitchen.country ?? '')
      setCurrency(kitchen.currency ?? 'EUR')
    }
  }, [kitchen])

  const handleSave = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/kitchens/current', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, country, currency }),
      })
      if (res.ok) {
        toast.success('Configuración guardada')
        refresh()
      } else {
        toast.error('Error al guardar')
      }
    } catch { toast.error('Error de conexión') } finally { setLoading(false) }
  }

  return (
    <div className="space-y-6">
      <FadeIn>
        <div>
          <h1 className="text-2xl font-display font-bold tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-primary" /> Configuración
          </h1>
          <p className="text-muted-foreground mt-1">Ajustes de tu cocina</p>
        </div>
      </FadeIn>
      <FadeIn delay={0.1}>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Building2 className="w-5 h-5" /> Datos del Negocio</CardTitle>
            <CardDescription>Modifica los datos de tu cocina</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Nombre del Negocio</Label>
              <Input value={name} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>País</Label>
                <Input value={country} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCountry(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Moneda</Label>
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CURRENCIES.map((c: { value: string; label: string }) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <Button onClick={handleSave} loading={loading}>Guardar Cambios</Button>
          </CardContent>
        </Card>
      </FadeIn>
    </div>
  )
}
