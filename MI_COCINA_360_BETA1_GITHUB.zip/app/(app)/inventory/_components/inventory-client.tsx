'use client'

import { useState, useEffect, useCallback } from 'react'
import { useKitchen } from '@/lib/kitchen-context'
import { formatCurrency } from '@/lib/currency'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { FadeIn } from '@/components/ui/animate'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Search, Package, AlertTriangle, CheckCircle2 } from 'lucide-react'

export function InventoryClient() {
  const { kitchen } = useKitchen()
  const [ingredients, setIngredients] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showLowOnly, setShowLowOnly] = useState(false)

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch('/api/ingredients')
      if (res.ok) setIngredients(await res.json())
    } catch { console.error('Failed') } finally { setLoading(false) }
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  const filtered = (ingredients ?? []).filter((i: any) => {
    const matchSearch = (i?.name ?? '').toLowerCase().includes(search.toLowerCase())
    const isLow = (i?.currentStock ?? 0) < (i?.minStock ?? 0)
    return matchSearch && (!showLowOnly || isLow)
  })

  const lowStockCount = (ingredients ?? []).filter((i: any) => (i?.currentStock ?? 0) < (i?.minStock ?? 0)).length
  const currency = kitchen?.currency ?? 'EUR'
  const totalValue = (filtered ?? []).reduce((sum: number, i: any) => sum + (i?.currentStock ?? 0) * (i?.costPerUnit ?? 0), 0)

  return (
    <div className="space-y-6">
      <FadeIn>
        <div>
          <h1 className="text-2xl font-display font-bold tracking-tight flex items-center gap-2">
            <Package className="w-6 h-6 text-primary" /> Inventario
          </h1>
          <p className="text-muted-foreground mt-1">Control de stock de ingredientes</p>
        </div>
      </FadeIn>

      {/* Summary Cards */}
      <FadeIn delay={0.1}>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-sm text-muted-foreground">Total Ingredientes</p>
              <p className="text-2xl font-mono font-bold mt-1">{ingredients?.length ?? 0}</p>
            </CardContent>
          </Card>
          <Card className={lowStockCount > 0 ? 'border-amber-300 bg-amber-50/50' : ''}>
            <CardContent className="pt-6 text-center">
              <p className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                {lowStockCount > 0 && <AlertTriangle className="w-4 h-4 text-amber-500" />}
                Stock Bajo
              </p>
              <p className="text-2xl font-mono font-bold mt-1">{lowStockCount}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-sm text-muted-foreground">Valor Total</p>
              <p className="text-2xl font-mono font-bold mt-1">{formatCurrency(totalValue, currency)}</p>
            </CardContent>
          </Card>
        </div>
      </FadeIn>

      <FadeIn delay={0.15}>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative max-w-sm flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Buscar ingredientes..." className="pl-10" value={search}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearch(e.target.value)} />
          </div>
          <button
            onClick={() => setShowLowOnly(!showLowOnly)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors border ${
              showLowOnly ? 'bg-amber-100 border-amber-300 text-amber-700' : 'bg-background border-border text-muted-foreground hover:bg-accent'
            }`}
          >
            <AlertTriangle className="w-4 h-4 inline mr-1" />
            Solo Stock Bajo {lowStockCount > 0 && `(${lowStockCount})`}
          </button>
        </div>
      </FadeIn>

      <FadeIn delay={0.2}>
        <Card>
          <CardContent className="p-0">
            {loading ? <div className="p-8 text-center text-muted-foreground">Cargando...</div>
            : filtered.length === 0 ? <div className="p-8 text-center text-muted-foreground">Sin ingredientes en inventario</div>
            : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ingrediente</TableHead>
                      <TableHead>Categoría</TableHead>
                      <TableHead className="text-right">Stock Actual</TableHead>
                      <TableHead>Unidad</TableHead>
                      <TableHead className="text-right">Stock Mínimo</TableHead>
                      <TableHead className="text-right">Valor</TableHead>
                      <TableHead className="text-center">Estado</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((i: any) => {
                      const isLow = (i?.currentStock ?? 0) < (i?.minStock ?? 0)
                      return (
                        <TableRow key={i?.id} className={isLow ? 'bg-amber-50/50' : ''}>
                          <TableCell className="font-medium">{i?.name ?? ''}</TableCell>
                          <TableCell><Badge variant="secondary">{i?.category ?? ''}</Badge></TableCell>
                          <TableCell className={`text-right font-mono ${isLow ? 'text-amber-600 font-medium' : ''}`}>{i?.currentStock ?? 0}</TableCell>
                          <TableCell>{i?.unit ?? ''}</TableCell>
                          <TableCell className="text-right font-mono">{i?.minStock ?? 0}</TableCell>
                          <TableCell className="text-right font-mono">{formatCurrency((i?.currentStock ?? 0) * (i?.costPerUnit ?? 0), currency)}</TableCell>
                          <TableCell className="text-center">
                            {isLow ? (
                              <Badge className="bg-amber-100 text-amber-700 gap-1">
                                <AlertTriangle className="w-3 h-3" /> Bajo
                              </Badge>
                            ) : (
                              <Badge className="bg-emerald-100 text-emerald-700 gap-1">
                                <CheckCircle2 className="w-3 h-3" /> OK
                              </Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </FadeIn>
    </div>
  )
}
