'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useKitchen } from '@/lib/kitchen-context'
import {
  LayoutDashboard,
  Carrot,
  Truck,
  BookOpen,
  ClipboardList,
  Package,
  Settings,
  ChefHat,
} from 'lucide-react'

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Inicio', icon: LayoutDashboard },
  { href: '/ingredients', label: 'Ingredientes', icon: Carrot },
  { href: '/suppliers', label: 'Proveedores', icon: Truck },
  { href: '/recipes', label: 'Recetas', icon: BookOpen },
  { href: '/delivery-notes', label: 'Albaranes', icon: ClipboardList },
  { href: '/inventory', label: 'Inventario', icon: Package },
  { href: '/settings', label: 'Configuración', icon: Settings },
]

export function AppSidebar() {
  const pathname = usePathname()
  const { kitchen } = useKitchen()

  return (
    <>
      <div className="flex items-center gap-3 px-2 py-4 mb-4">
        <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center flex-shrink-0">
          <ChefHat className="w-5 h-5 text-primary-foreground" />
        </div>
        <div className="min-w-0">
          <p className="font-display font-bold text-sm truncate">MI COCINA 360</p>
          <p className="text-xs text-muted-foreground truncate">{kitchen?.name ?? 'Cargando...'}</p>
        </div>
      </div>
      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map((item: { href: string; label: string; icon: any }) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
              )}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {item.label}
            </Link>
          )
        })}
      </nav>
    </>
  )
}
