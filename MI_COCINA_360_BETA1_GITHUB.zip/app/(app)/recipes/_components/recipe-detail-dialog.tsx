'use client'

import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { useKitchen } from '@/lib/kitchen-context'
import { formatCurrency } from '@/lib/currency'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
  recipe: any
}

export function RecipeDetailDialog({ open, onOpenChange, recipe }: Props) {
  const { kitchen } = useKitchen()
  const currency = kitchen?.currency ?? 'EUR'
  if (!recipe) return null

  const totalCost = (recipe?.ingredients ?? []).reduce(
    (sum: number, ri: any) => sum + (ri?.quantity ?? 0) * (ri?.ingredient?.costPerUnit ?? 0), 0
  )
  const costPerPortion = totalCost / Math.max(recipe?.yield ?? 1, 1)
  const foodCostPct = (recipe?.sellingPrice ?? 0) > 0 ? (costPerPortion / (recipe?.sellingPrice ?? 1)) * 100 : 0

  const getFoodCostColor = (pct: number) => {
    if (pct <= 30) return 'text-emerald-600 bg-emerald-50'
    if (pct <= 40) return 'text-amber-600 bg-amber-50'
    return 'text-red-600 bg-red-50'
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {recipe?.name ?? ''}
            <Badge variant="secondary">{recipe?.category ?? ''}</Badge>
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-6">
          {/* Cost Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-muted/50 rounded-lg p-3 text-center">
              <p className="text-xs text-muted-foreground">Coste MP Total</p>
              <p className="text-lg font-mono font-bold mt-1">{formatCurrency(totalCost, currency)}</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-3 text-center">
              <p className="text-xs text-muted-foreground">Coste/Porción</p>
              <p className="text-lg font-mono font-bold mt-1">{formatCurrency(costPerPortion, currency)}</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-3 text-center">
              <p className="text-xs text-muted-foreground">Precio Venta</p>
              <p className="text-lg font-mono font-bold mt-1">{formatCurrency(recipe?.sellingPrice ?? 0, currency)}</p>
            </div>
            <div className={`rounded-lg p-3 text-center ${getFoodCostColor(foodCostPct)}`}>
              <p className="text-xs opacity-80">Food Cost</p>
              <p className="text-lg font-mono font-bold mt-1">{foodCostPct?.toFixed?.(1) ?? '0.0'}%</p>
            </div>
          </div>

          {/* Ingredients Breakdown */}
          <div>
            <h3 className="font-medium mb-2">Desglose de Ingredientes ({recipe?.yield ?? 1} porciones)</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ingrediente</TableHead>
                  <TableHead className="text-right">Cantidad</TableHead>
                  <TableHead>Unidad</TableHead>
                  <TableHead className="text-right">Coste/Ud</TableHead>
                  <TableHead className="text-right">Subtotal</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(recipe?.ingredients ?? []).map((ri: any, idx: number) => {
                  const subtotal = (ri?.quantity ?? 0) * (ri?.ingredient?.costPerUnit ?? 0)
                  return (
                    <TableRow key={idx}>
                      <TableCell className="font-medium">{ri?.ingredient?.name ?? ''}</TableCell>
                      <TableCell className="text-right font-mono">{ri?.quantity ?? 0}</TableCell>
                      <TableCell>{ri?.ingredient?.unit ?? ''}</TableCell>
                      <TableCell className="text-right font-mono">{formatCurrency(ri?.ingredient?.costPerUnit ?? 0, currency)}</TableCell>
                      <TableCell className="text-right font-mono font-medium">{formatCurrency(subtotal, currency)}</TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>

          {recipe?.notes && (
            <div>
              <h3 className="font-medium mb-2">Notas de Preparación</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{recipe.notes}</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
