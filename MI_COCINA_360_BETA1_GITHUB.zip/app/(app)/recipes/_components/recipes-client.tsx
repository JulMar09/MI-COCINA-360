'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSearchParams } from 'next/navigation'
import { useKitchen } from '@/lib/kitchen-context'
import { formatCurrency } from '@/lib/currency'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { FadeIn } from '@/components/ui/animate'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Plus, Search, Pencil, Trash2, BookOpen, Eye } from 'lucide-react'
import { toast } from 'sonner'
import { RecipeDialog } from './recipe-dialog'
import { RecipeDetailDialog } from './recipe-detail-dialog'

export function RecipesClient() {
  const { kitchen } = useKitchen()
  const searchParams = useSearchParams()
  const [recipes, setRecipes] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [viewItem, setViewItem] = useState<any>(null)

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch('/api/recipes')
      if (res.ok) setRecipes(await res.json())
    } catch { console.error('Failed') } finally { setLoading(false) }
  }, [])

  useEffect(() => { fetchData() }, [fetchData])
  useEffect(() => {
    if (searchParams?.get('action') === 'new') setDialogOpen(true)
  }, [searchParams])

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar esta receta?')) return
    try {
      const res = await fetch(`/api/recipes/${id}`, { method: 'DELETE' })
      if (res.ok) { toast.success('Receta eliminada'); fetchData() }
      else toast.error('Error al eliminar')
    } catch { toast.error('Error de conexión') }
  }

  const filtered = (recipes ?? []).filter((r: any) =>
    (r?.name ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (r?.category ?? '').toLowerCase().includes(search.toLowerCase())
  )

  const currency = kitchen?.currency ?? 'EUR'

  const getFoodCostColor = (pct: number) => {
    if (pct <= 30) return 'text-emerald-600'
    if (pct <= 40) return 'text-amber-600'
    return 'text-destructive'
  }

  return (
    <div className="space-y-6">
      <FadeIn>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-primary" /> Recetas
            </h1>
            <p className="text-muted-foreground mt-1">Gestiona tus recetas con cálculo automático de costes</p>
          </div>
          <Button onClick={() => { setEditItem(null); setDialogOpen(true) }}>
            <Plus className="w-4 h-4 mr-2" /> Nueva Receta
          </Button>
        </div>
      </FadeIn>
      <FadeIn delay={0.1}>
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Buscar recetas..." className="pl-10" value={search}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearch(e.target.value)} />
        </div>
      </FadeIn>
      <FadeIn delay={0.2}>
        <Card>
          <CardContent className="p-0">
            {loading ? <div className="p-8 text-center text-muted-foreground">Cargando...</div>
            : filtered.length === 0 ? <div className="p-8 text-center text-muted-foreground">{search ? 'Sin resultados' : 'No hay recetas. ¡Crea la primera!'}</div>
            : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Categoría</TableHead>
                      <TableHead className="text-center">Porciones</TableHead>
                      <TableHead className="text-right">Coste Total</TableHead>
                      <TableHead className="text-right">Coste/Porción</TableHead>
                      <TableHead className="text-right">PVP</TableHead>
                      <TableHead className="text-right">Food Cost %</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((r: any) => (
                      <TableRow key={r?.id}>
                        <TableCell className="font-medium">{r?.name ?? ''}</TableCell>
                        <TableCell><Badge variant="secondary">{r?.category ?? ''}</Badge></TableCell>
                        <TableCell className="text-center font-mono">{r?.yield ?? 1}</TableCell>
                        <TableCell className="text-right font-mono">{formatCurrency(r?.totalCost ?? 0, currency)}</TableCell>
                        <TableCell className="text-right font-mono">{formatCurrency(r?.costPerPortion ?? 0, currency)}</TableCell>
                        <TableCell className="text-right font-mono">{formatCurrency(r?.sellingPrice ?? 0, currency)}</TableCell>
                        <TableCell className="text-right">
                          <span className={`font-mono font-medium ${getFoodCostColor(r?.foodCostPercent ?? 0)}`}>
                            {(r?.foodCostPercent ?? 0)?.toFixed?.(1) ?? '0.0'}%
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon-sm" onClick={() => { setViewItem(r); setDetailOpen(true) }}><Eye className="w-4 h-4" /></Button>
                            <Button variant="ghost" size="icon-sm" onClick={() => { setEditItem(r); setDialogOpen(true) }}><Pencil className="w-4 h-4" /></Button>
                            <Button variant="ghost" size="icon-sm" onClick={() => handleDelete(r?.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </FadeIn>
      <RecipeDialog open={dialogOpen} onOpenChange={setDialogOpen} recipe={editItem}
        onSuccess={() => { fetchData(); setDialogOpen(false); setEditItem(null) }} />
      <RecipeDetailDialog open={detailOpen} onOpenChange={setDetailOpen} recipe={viewItem} />
    </div>
  )
}
